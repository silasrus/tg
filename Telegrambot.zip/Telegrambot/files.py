main_db = 'data/db/main_data.db'

sost_bd = 'data/bd/sost.bd'
bot_message_bd = 'data/bd/bot_message_bd.bd'
payments_bd = 'data/bd/payments_bd.bd'

working_log = 'data/working_log.log'

admins_list = 'data/lists/admins_list.txt'
users_list = 'data/lists/chatid_list.txt'
blockusers_list = 'data/lists/blockusers_list.txt'


